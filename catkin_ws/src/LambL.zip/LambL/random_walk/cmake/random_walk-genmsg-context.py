# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/lily/Desktop/work/catki_ws/catkin_ws/src/LambL/random_walk/msg/Num.msg"
services_str = "/home/lily/Desktop/work/catki_ws/catkin_ws/src/LambL/random_walk/srv/AddTwoInts.srv"
pkg_name = "random_walk"
dependencies_str = "std_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "random_walk;/home/lily/Desktop/work/catki_ws/catkin_ws/src/LambL/random_walk/msg;std_msgs;/opt/ros/noetic/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python3"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/noetic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
